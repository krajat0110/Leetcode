// https://leetcode.com/problems/longest-consecutive-sequence

class Solution {
public:
    int longestConsecutive(vector<int>& nums) {
        if(nums.size() == 0) return 0;
        unordered_map<int , int>map;
        int len = -1;
        for(auto ele : nums){
            map[ele]++;
        }
        
        for(int ele : nums){
            if(map.find(ele) == map.end()) continue;
           int prev = ele - 1 , next = ele + 1;
            map.erase(ele);
            while(map.find(prev) != map.end()) map.erase(prev--);
            while(map.find(next) != map.end()) map.erase(next++);
            len = max(len , next - prev - 1);
          //  cout<<next<<" "<<prev<<" "<<len<<endl;
        }

        return len;
    }
};