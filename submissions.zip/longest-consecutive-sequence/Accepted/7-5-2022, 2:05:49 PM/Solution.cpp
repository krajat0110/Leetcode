// https://leetcode.com/problems/longest-consecutive-sequence

class Solution {
public:
    int longestConsecutive(vector<int>& nums) {
        int n = nums.size();
        if(n == 0) return 0;
        sort(nums.begin() , nums.end());
        int maxlen = 0 , len = 1;
        for(int i = 1 ; i < n ;i++){
            if(nums[i] == nums[i-1]) continue;
           else if(nums[i] == nums[i - 1] + 1){
                len++;
            }else{
                maxlen = max(maxlen , len);
                len = 1;
            }
        }
        return max(maxlen,len);
    }
};