// https://leetcode.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    TreeNode *buildTree1(vector<int> &preorder , int psi , int pei , vector<int> &inorder , int isi , int iei){
    if(isi > iei)  return NULL;  
    int idx = isi;
    while(preorder[psi] != inorder[idx])
    idx++;     
    int tele = idx  - isi ;     
    TreeNode *root = new TreeNode(preorder[psi]);      
  //  cout<<idx<<" "<<isi <<endl;    
    root -> left = buildTree1(preorder , psi + 1 , psi + tele , inorder , isi , idx - 1);
    root -> right = buildTree1(preorder, psi + tele + 1 , pei , inorder, idx + 1 , iei);
    return root;
    }

TreeNode *buildTree(vector<int> preorder, vector<int> inorder){

    int n = preorder.size();
    return buildTree1(preorder , 0 , n-1 , inorder , 0 , n - 1);
 }
};