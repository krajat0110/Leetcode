// https://leetcode.com/problems/decode-string

class Solution {
public:
    string decodeString(const string& s, int& i) {
        string res;
        
        while (i < s.length() && s[i] != ']') {
            if (!isdigit(s[i])){ //a - z wale char ko 
                res += s[i++];
            }
            else {
                int n = 0;
                while (i < s.length() && isdigit(s[i]))
                    n = n * 10 + s[i++] - '0';
                 //cout<<n<<" ";   
                i++; // '['
                string t = decodeString(s, i);
                i++; // ']'
                
                while (n-- > 0) //3 he val to loop 3 baar chalega and then 3 times a ko insert karega 
                    res += t;
            }
        }
        
        return res;
    }

    string decodeString(string s) {
        int i = 0;
        return decodeString(s, i);
    }
};