// https://leetcode.com/problems/subarray-sums-divisible-by-k

class Solution {
public:
    int subarraysDivByK(vector<int>& nums, int k) {
        unordered_map<int , int > rem;
        int ei = 0 , sum = 0 , ans = 0 , n = nums.size();
        rem[0] = 1; // first ele ko subarray
        while(ei < n){
            sum += nums[ei++];
            int r = (sum % k + k) % k;
            
            ans += rem[r];
            rem[r]++;
        }
        return ans;
    }
};