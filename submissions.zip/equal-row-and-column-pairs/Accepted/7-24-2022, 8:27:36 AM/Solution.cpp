// https://leetcode.com/problems/equal-row-and-column-pairs

class Solution {
public:
    int equalPairs(vector<vector<int>>& grid) {
        vector<int>row , col;
        int cnt = 0 , k = 0;
        int n = grid.size();
        while(k < n){
        for(int i = 0 ; i < n ; i++){
            row.push_back(grid[i][k]);
           // cout<<row[i]<<" ";
        }
            cout<<endl;
            int cc = 0;
        while(cc < n){
          for(int j = 0 ; j < n ; j++)
            col.push_back(grid[cc][j]);
                
            if(row == col) cnt++;
            cc++;
            col.clear();    
         }
            k++;
            row.clear();
        }
        return cnt;
    }
};