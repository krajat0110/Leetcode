// https://leetcode.com/problems/largest-combination-with-bitwise-and-greater-than-zero

class Solution {
public:
    int largestCombination(vector<int>& candidates) {
        vector<int> v(24);
        
        for(auto i : candidates){
            int j = 0;
            // cout << i << endl;
            while(i > 0){
                if(i % 2){
                    v[j]++;
                    // cout << j << " ";
                }
                i /= 2;
                j++;
            }
            // cout << endl;
        }
//         for(auto i : v){
//             cout << i << " ";
//         }
//         cout << endl;
        
        int ans = v[0];
        
        int e = 0;
        for(int i = v.size()-1; i >=0; i--){
            if(v[i] > 0){
                e = i;
                break;
            }
        }
        for(int i = 0; i <= e; i++){
            ans = max(ans, v[i]);
        }
        
        return ans;
    }
};