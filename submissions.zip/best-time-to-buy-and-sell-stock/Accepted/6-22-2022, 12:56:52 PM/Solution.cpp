// https://leetcode.com/problems/best-time-to-buy-and-sell-stock

class Solution {
public:
    int maxProfit(vector<int>& prices) {
        int dpi10 = 0 , dpi11 = -(int)1e9;
        //buy = 1 ,sell = 0;
        for(int price : prices){   
        dpi10 = max(dpi10 , dpi11 + price);
        dpi11 = max(dpi11 , 0 - price);
    }
        return dpi10;
    }
};