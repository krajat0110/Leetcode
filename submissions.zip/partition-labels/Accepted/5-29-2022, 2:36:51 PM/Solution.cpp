// https://leetcode.com/problems/partition-labels

class Solution {
public:
    vector<int> partitionLabels(string s) {
        if(s.size() == 0) return {};
        
        vector<int>ans;
        vector<int>lastidx(26);
        
        for(int i = 0 ;i < s.size(); i++){
            lastidx[s[i] - 'a'] = i; //started last idx of charater
        }
        
        int start = 0 , end = 0;
        
        for(int i = 0 ; i < s.size(); i++){
            end = max(end , lastidx[s[i] - 'a']);// iterate the string 
            
            if(end == i){  //if char is equal to last idx push and update the start 
                ans.push_back(end - start + 1);
                start  = end +1;
            }
        }
        return ans;
    }
};