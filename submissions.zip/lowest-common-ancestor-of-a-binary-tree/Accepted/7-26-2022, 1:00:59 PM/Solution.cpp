// https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    TreeNode *LCAnode = NULL;
    bool LCA(TreeNode *root ,TreeNode *p , TreeNode *q){
      if(root == NULL ) return false;
        
       bool selfplaced = root == p || root == q;
       
       bool leftplaced = LCA(root -> left , p , q);
       bool rightplaced = LCA(root -> right , p , q);
        
       if((leftplaced && rightplaced) || (leftplaced && selfplaced) || (rightplaced && selfplaced))
          LCAnode = root;
        
        return leftplaced || rightplaced || selfplaced;

    }
    
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
        LCA(root , p , q);
        return LCAnode;
    }
};