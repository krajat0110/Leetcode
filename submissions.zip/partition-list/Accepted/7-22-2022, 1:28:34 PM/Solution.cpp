// https://leetcode.com/problems/partition-list

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* partition(ListNode* head, int x) {
         if(head == NULL || head -> next == NULL){
        return head;
    }

    ListNode *small = new ListNode(-1);
    ListNode *sn = small;
    ListNode *large = new ListNode(-1);
    ListNode *ln = large;

    ListNode *curr = head; 
    while(curr != NULL ){        
        // while(curr -> val != x && flag == false){
        //     sn -> next = curr;
        //     sn  = sn-> next;
        //     curr = curr -> next;
        // }
        // if(curr -> val == x){
        //     flag = true;
        //     ln -> next = curr;
        //     ln = ln -> next;
        // } 
        // curr = curr -> next;
        
        if(curr -> val < x){
            sn -> next = curr;
            sn = sn -> next;
        }else{
            ln -> next = curr; 
            ln = ln -> next;
        }
         curr = curr -> next;
    }
        
    ln -> next = NULL;
    sn -> next = large -> next;

    return small -> next;
    }
};