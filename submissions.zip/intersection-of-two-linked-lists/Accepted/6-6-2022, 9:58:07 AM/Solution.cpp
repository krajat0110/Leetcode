// https://leetcode.com/problems/intersection-of-two-linked-lists

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
       ListNode *tailA = headA , *tailB = headB;
        while(tailA != NULL && tailA -> next != NULL) tailA = tailA -> next;
        while(tailB != NULL && tailB -> next != NULL) tailB = tailB -> next;
        
        if(tailA != NULL && tailB != NULL && tailA != tailB) return NULL;
        
            tailA -> next = headB;
            
            ListNode *slow = headA,*fast = headA;
            while(fast != NULL && fast -> next != NULL){
            slow = slow -> next;
            fast = fast -> next -> next;
            
                if(slow == fast ) break;
            } 
            slow = headA;
            while(slow != fast ){
                slow = slow -> next;
                fast = fast -> next;
                
            }
            tailA -> next = NULL;
        return slow;
    }
};