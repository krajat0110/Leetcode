// https://leetcode.com/problems/repeated-substring-pattern

class Solution {
public:
    bool repeatedSubstringPattern(string s) {
        int n = s.size();
        string a = "" , c;
        for(int i = 0 ; i < n/2 ; i++){//till half of the string since thats the max substring
            a += s[i];
            c = a;
            if(n % c.size() == 0){ //checking if length of s is a multiple of length of subsrting
              //  cout<<a<<" "<<c<<endl;
                int len = n/c.size(); //number of time suubstring need to be repeated
                while(len > 1){ //making the repeated substring
                    c += a;
                    len--;
                }
                if(c == s)
                    return true;
            }
        }
        return false;
    }
};