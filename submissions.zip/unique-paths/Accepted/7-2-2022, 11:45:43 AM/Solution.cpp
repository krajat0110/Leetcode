// https://leetcode.com/problems/unique-paths

class Solution {
public:
    
int mazePath_tabu(int SR, int SC, int ER, int EC, vector<vector<int>> &dp, vector<vector<int>> &dir)
{
    for (int sr = ER; sr >= SR; sr--)
    {
        for (int sc = EC; sc >= SC; sc--)
        {
            if (sr == ER && sc == EC)
            {
                dp[sr][sc] = 1;
                continue;
            }
            int count = 0;
            for (auto d : dir)
            {
                int r = sr + d[0], c = sc + d[1];
                if (r >= 0 && c >= 0 && r < dp.size() && c < dp[0].size())
                {
                    count += dp[r][c];
                }
            }
            dp[sr][sc] = count;
        }
    }
    return dp[SR][SC];
}
    
    
    int uniquePaths(int ER , int EC) {
    int SR = 0, SC = 0;
    vector<vector<int>> dp(ER + 1, vector<int>(EC + 1));

    vector<vector<int>> dir = {{1, 0}, {0, 1}};
    return mazePath_tabu(SR, SC, ER -1 , EC - 1, dp, dir);
    }
};