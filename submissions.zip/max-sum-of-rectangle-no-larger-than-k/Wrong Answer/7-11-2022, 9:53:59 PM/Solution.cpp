// https://leetcode.com/problems/max-sum-of-rectangle-no-larger-than-k

class Solution {
public:  
    int kadanesAlgoWithSumUnderK(vector<int> arr, int k) {
        int gsum = -(int) 1e9, csum = 0;
        for (int ele : arr) {
            csum += ele;
            csum = max(csum, ele);
            gsum = max(gsum, csum);

            if (gsum >= k)
                return gsum;
        }

        return gsum;
}
    
    int maxSumSubmatrix(vector<vector<int>>& arr, int k) {
        int n = arr.size(), m = arr[0].size();
        int maxRes = -1;

        for (int fixedRow = 0; fixedRow < n; fixedRow++) {

            vector<int> prefixColArray (m,0);
            for (int row = fixedRow; row < n; row++) {
                for (int col = 0; col < m; col++)
                    prefixColArray[col] += arr[row][col];

                int sum = kadanesAlgoWithSumUnderK(prefixColArray, k);

                if (sum == k)
                    return sum;
                else if (sum < k) {
                    maxRes = max(maxRes, sum);
                    continue;
                }
             // Otherwise, try binary search of running sums
               int cur_sum = 0;
                set<int> s{0};
                for (auto& sum: prefixColArray)
                {
                    cur_sum += sum;
                    auto it = s.lower_bound(cur_sum - k);
                    if (it != s.end())
                        maxRes = max(maxRes, cur_sum - *it);
                    if (maxRes == k)
                        return k;
                    s.insert(cur_sum);
                }
            }
        }

        return maxRes;
    }
};
        