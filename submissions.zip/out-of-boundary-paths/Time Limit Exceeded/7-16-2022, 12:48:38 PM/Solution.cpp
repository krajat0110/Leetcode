// https://leetcode.com/problems/out-of-boundary-paths

class Solution {
public:
    int dp[51][51][51];
    int mod = 1e9 + 7;
    
    int dfs(int m , int n , int maxMove , int sr , int sc){
        if(sr == m || sc == n || sr < 0 || sc < 0) return 1;
        
        if(maxMove == 0) return 0;
     
        
        if(dp[sr][sc][maxMove] != -1)
            return dp[sr][sc][maxMove];
        
        long res = 0; 
        res += dfs(m , n , maxMove - 1 , sr + 1 , sc) ;
        res += dfs(m , n , maxMove - 1 , sr - 1 , sc) ;
        res += dfs(m , n , maxMove - 1 , sr , sc + 1) ;
        res += dfs(m , n , maxMove - 1 , sr , sc - 1) ;

        return dp[m][n][maxMove] = res % mod;

    }
    
    int findPaths(int m, int n, int maxMove, int sr, int sc) {
        memset(dp , -1 , sizeof(dp));
        return dfs(m , n , maxMove , sr , sc) % mod;
    }
};