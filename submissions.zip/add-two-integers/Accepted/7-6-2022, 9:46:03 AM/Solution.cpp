// https://leetcode.com/problems/add-two-integers

class Solution {
public:
    int sum(int num1, int num2) {
        return num1 + num2;
    }
};