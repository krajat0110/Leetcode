// https://leetcode.com/problems/fruit-into-baskets

class Solution {
public:
    int totalFruit(vector<int>& fruits) {
        int si = 0 , ei = 0, cnt = 0 , ans = 0 , n = fruits.size();
        vector<int>freq(1000001, 0);
        
        while(ei < n){
            if(freq[fruits[ei++]]++ == 0) cnt++;
            
            while(cnt > 2){
              if(freq[fruits[si++]]-- == 1) cnt--;  
            }
            ans = max(ans , ei - si);
        }
        return ans;
    }
};