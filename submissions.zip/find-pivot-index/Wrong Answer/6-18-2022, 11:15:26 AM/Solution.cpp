// https://leetcode.com/problems/find-pivot-index

class Solution {
public:
    int pivotIndex(vector<int>& nums) {
        int n = nums.size() , si = 0 , ei = n-1;
        int sum1 = 0 , sum2 = 0;
        if(nums[si] < nums[ei]){ 
            sum1 += nums[si];
        }else{
            sum2 += nums[ei]; 
        }
      //  cout<<sum1<<"&"<<sum2<<endl;
        while(si < ei){
            if(sum1 > sum2){
                ei--;
                sum2+=nums[ei];
            }else{
                si++;
                sum1 += nums[si];             
            }
        //    cout<<sum1 << " "<<sum2<<endl;
            if(sum1 == sum2){
                return si == 0 ? si : si+1;
            }
           
        }
        return -1;
    }
};