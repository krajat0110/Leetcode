// https://leetcode.com/problems/k-concatenation-maximum-sum

class Solution {
public:
    int mod = (int)1e9 + 7;
    
    int kadansalgo(vector<int>& arr, int k){
        long csum = 0 , gsum = 0;
        int n = arr.size();
        for(int i = 0 ; i < k * n ; i++){
            int ele = arr[i%n];
            csum += ele;
            
            if(csum > gsum)
               gsum = csum; 
            if(csum <= 0)
                csum = 0;
        }
        return (int)gsum % mod;
    }
    
    int kConcatenationMaxSum(vector<int>& arr, int k) {
        long sum = 0 , prevsum = 0;
        for(int i = 1 ; i <= 3;i++){ //to know tha AP series pattern
            prevsum = sum;
            sum = kadansalgo(arr,i);
            if(i == k) //means k agar 3 se chota ho to
                return (int)sum;
        }
        return (int)((prevsum + (k - 2) * (sum - prevsum)) % mod);
    }
};