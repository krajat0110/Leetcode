// https://leetcode.com/problems/best-poker-hand

class Solution {
public:
    string bestHand(vector<int>& ranks, vector<char>& suits) { 
        unordered_map<int,int>map1;
        unordered_map<char,int>map2;
        int ans2 = -1e9 , ans1 = -1e9;
        
        for(auto ele : ranks)map1[ele]++;
        for(auto ele : suits)map2[ele]++;
        
        for(auto ele1 : map1){
            ans1 = max(ans1,ele1.second);
        }
         for(auto ele1 : map2){
            ans2 = max(ans2,ele1.second);
        }
        if(ans2 == 5){
            return "Flush";
        }else if(ans1 == 1){
            return "High Card";
        }else if(ans1 == 2){
            return "Pair";
        }else if(ans1 > 2){
            return "Three of a Kind";
        }
        return "";
    }
};