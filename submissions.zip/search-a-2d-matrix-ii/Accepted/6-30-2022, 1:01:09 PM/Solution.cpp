// https://leetcode.com/problems/search-a-2d-matrix-ii

class Solution {
public:
    bool searchMatrix(vector<vector<int>>& matrix, int target) {
        int n = matrix.size(), m = matrix[0].size(), si = n - 1, ei = 0;
        while (si >= 0 && ei < m) {
        int ele = matrix[si][ei];
        if (ele == target)
            return true;
            ele > target ? si-- : ei++;
        }
    return false;
    }
};