// https://leetcode.com/problems/maximum-erasure-value

class Solution {
public:
    int maximumUniqueSubarray(vector<int>& s) {
        if(s.size() < 2) return s[0];
         int n=s.size(),si=0,ei=0,len=0,count=0 , maxlen = -1e9 , maxsum = 0;
        vector<int> freq(128,0);
        
        while(ei<n){
            if(freq[s[ei++]]++ > 0){
                count++;

            }
           // cout<<ei<<" "<<si<<" "<<count<<endl;
            while(count>0){ 
                if(freq[s[si++]]-- > 1) count--; 
             }     
                len = ei - si;
             //   cout<<len<<"->";
             if(len > maxlen){   
                 int sum = 0;
            for(int i = si ; i < ei ; i++)
                sum += s[i];
                maxlen  = len;
                maxsum = max(maxsum , sum);      
        } 
     } 
        return maxsum;
    }
};