// https://leetcode.com/problems/maximum-erasure-value

class Solution {
public:
    int maximumUniqueSubarray(vector<int>& s) {
       // if(s.size() < 2) return s[0];
         int n=s.size(),si =0 ,ei=0,count=0 , sum = 0, maxsum = 0;
        unordered_map<int, int> freqMap;
        
        while(ei<n){          
            int right = s[ei++];
            sum += right;
            freqMap[right]++;
            
            while(freqMap[right] > 1){ 
            int left = s[si++];
            freqMap[left]--;
            sum -= left;

             }     
                maxsum = max(maxsum , sum);       
     } 
        return maxsum;
    }
};