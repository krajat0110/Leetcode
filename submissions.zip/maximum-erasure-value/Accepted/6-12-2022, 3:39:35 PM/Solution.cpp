// https://leetcode.com/problems/maximum-erasure-value

class Solution {
public:
    int maximumUniqueSubarray(vector<int>& s) {
       // if(s.size() < 2) return s[0];
         int n=s.size(),si =0 ,ei=0,sum = 0, maxsum = 0;
        unordered_map<int, int> freqMap;
        
        while(ei<n){  
            int i = ei;
            sum += s[ei];
            freqMap[s[ei++]]++;
            
            while(freqMap[s[i]] > 1){ 
             sum -= s[si];
            freqMap[s[si++]]--;

             }     
                maxsum = max(maxsum , sum);       
     } 
        return maxsum;
    }
};