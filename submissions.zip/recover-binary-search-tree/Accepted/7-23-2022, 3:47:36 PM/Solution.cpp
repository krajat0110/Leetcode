// https://leetcode.com/problems/recover-binary-search-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    
    TreeNode *getRightMostNode(TreeNode *node , TreeNode*curr){
        while(node -> right != NULL && node -> right != curr){
            node = node -> right;
        }
        return node;
    }
    
    void recoverTree(TreeNode* root) {
    TreeNode *curr = root;
    TreeNode *prev = nullptr , *a = NULL , *b = NULL;
    while (curr != nullptr)
    {
        TreeNode *left = curr->left;
        if (left == nullptr)
        {

            if (prev != nullptr && prev->val > curr->val)
            {
               if(a == NULL)
                   a = prev;
                b = curr;
            }
            prev = curr;
            curr = curr->right;
        }
        else
        {
            TreeNode *rightMostNode = getRightMostNode(left, curr);
            if (rightMostNode->right == nullptr)
            {                                // thread creation block
                rightMostNode->right = curr; // thread is created

                curr = curr->left;
            }
            else
            {                                   // thread destroy block
                rightMostNode->right = nullptr; // thread is cut down
               if (prev != nullptr && prev->val > curr->val)
            {
               if(a == NULL)
                   a = prev;
                   b = curr;
            }
                prev = curr;
                curr = curr->right;
            }
        }
      }
        if(a != NULL){
            int temp = a -> val;
            a->val = b->val;
            b -> val = temp;
        }
    }
};