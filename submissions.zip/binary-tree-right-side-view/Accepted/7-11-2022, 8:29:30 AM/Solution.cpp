// https://leetcode.com/problems/binary-tree-right-side-view

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    vector<int> rightSideView(TreeNode* root) {
    if (root == NULL)     return{};

    list<TreeNode *> que;
    que.push_back(root);
    int level = 0;
    
    vector<int >ans;
    while (que.size() != 0){
        int size = que.size();
        cout<<que.front() -> val<<endl;
        ans.push_back(que.front() -> val);
        while(size-- > 0){
            TreeNode *rnode = que.front();
            que.pop_front();
           
            if (rnode->right != NULL){
                que.push_back(rnode->right);
            }
            if (rnode->left != NULL){
                que.push_back(rnode->left);
            }   
        }
         level++;
    }
        return ans;

    }
};