// https://leetcode.com/problems/wiggle-subsequence

class Solution {
public:
    int wiggleMaxLength(vector<int>& nums) {
        int n = nums.size() , p = 0 , t = 0;
        for(int i = 1 ; i < n;++i){
            if(nums[i] > nums[i-1]) p = t+1;
            else if(nums[i] < nums[i-1]) t = p +1;
        }
        return min(n , max(p , t)) + 1;
    }
};