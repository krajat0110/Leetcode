// https://leetcode.com/problems/binary-search

class Solution {
public:
    int search(vector<int>& nums, int target) {
        int cnt = 0;
        for(int i = 0; i < nums.size() ; i++){
            if(nums[i] != target && nums[i] < target)
                cnt++;
            
            if(nums[i] == target) return cnt;
        }
        
         return -1;
    }
};