// https://leetcode.com/problems/3sum

class Solution {
public:
    vector<vector<int>> threeSum(vector<int>& nums) {
        int n = nums.size();
        vector<vector<int>> ans;
        sort(nums.begin(), nums.end());
        for(int i = 0;i < n;i++){
            if(i > 0 && nums[i] == nums[i-1])
                continue;
            int next = i+1, end = n-1;
            while(next < end){
                int sum = nums[next]+nums[end] + nums[i];
                if(sum < 0)
                    next++;
                else if(sum > 0)
                    end--;
                else{
                    vector<int> temp = {nums[i], nums[next], nums[end]};
                    ans.push_back(temp);
                    while(next < end && nums[next] == temp[1]) //remove duplicate ele 
                        next++;
                    while(next < end && nums[end] == temp[2])
                        end--;
                }
            }
        }
        return ans;
    }
};