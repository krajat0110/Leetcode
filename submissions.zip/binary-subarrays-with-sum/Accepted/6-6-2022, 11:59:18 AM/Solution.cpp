// https://leetcode.com/problems/binary-subarrays-with-sum

class Solution {
public:
    
    int subarrycnt(vector<int>& nums, int goal){
     int si = 0 , ei = 0 , sum = 0 , res = 0, n = nums.size();
       
      while(ei < n){
          if(nums[ei++] == 1) sum+= 1;
          
          while(sum > goal){
              sum -= nums[si++];
          }
           res += ei - si;
      }  
        return res;
    }
    
    int numSubarraysWithSum(vector<int>& nums, int goal) {
        return subarrycnt(nums , goal) - (goal != 0 ? subarrycnt(nums , goal -1) : 0);
    }
};