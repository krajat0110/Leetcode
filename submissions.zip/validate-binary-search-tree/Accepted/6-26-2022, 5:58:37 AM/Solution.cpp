// https://leetcode.com/problems/validate-binary-search-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    TreeNode *getrightmostnode(TreeNode *leftnode , TreeNode *curr){
        while(leftnode -> right != NULL && leftnode -> right != curr){
            leftnode = leftnode -> right;
        }
        return leftnode;
    }
    
bool isValidBST(TreeNode *root)
{
    TreeNode *curr = root;
    TreeNode *prev = nullptr;
    bool flag = true;
    while (curr != NULL)
    {
        TreeNode *leftnode = curr->left;
        if (leftnode == NULL)
        {

            if (prev != nullptr && prev->val >= curr->val)
            {
                flag = false;
            }
            prev = curr;

            curr = curr->right;
        }
        else
        {
            TreeNode *rightmostnode = getrightmostnode(leftnode, curr);
            if (rightmostnode->right == NULL)
            {
                rightmostnode->right = curr;
                curr = curr->left;
            }
            else
            {
                rightmostnode->right = NULL;

                if (prev != nullptr && prev->val >= curr->val)
                {
                    flag = false;
                }
                prev = curr;

                curr = curr->right;
            }
        }
    }
    return flag;
}
};