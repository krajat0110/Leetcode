// https://leetcode.com/problems/count-of-smaller-numbers-after-self

class Solution {
public:  
    void merge(vector<int> &count , vector<pair<int,int>> &v , int si , int mid , int ei){
        vector<pair<int , int >> temp(ei - si + 1);
        int i = si , j = mid + 1 , k = 0;
        
        while(i <= mid && j<= ei){
           if(v[i].first <= v[j].first){
               temp[k++] = v[j++];
           }else{
            count[v[i].second] += ei - j + 1;
            temp[k++] = v[i++];
          }
        }
        
        while(i <= mid){
            temp[k++] = v[i++];
        }
           while(j <= ei){
            temp[k++] = v[j++];
        }
        for(int z = si ; z <= ei ; z++){
            v[z] = temp[z - si];
          //  cout<<v[z].first<<" "<<v[z].second<<endl;
        }
    }
    
    void mergesort(vector<int> &count , vector<pair<int,int>>& v , int si , int ei){
        if(si < ei){
            int mid = si + (ei - si)/ 2;
            mergesort(count , v , si , mid);
            mergesort(count , v , mid + 1 , ei);
            merge(count , v , si , mid , ei);
        }   
    }
    
    vector<int> countSmaller(vector<int>& nums) {
        int n = nums.size();
        vector<pair<int,int>>v(n);
        for(int i = 0 ; i < n ; i++){
            pair<int,int>p;
            p.first = nums[i];
            p.second = i;
            v[i] = p;
        }
        vector<int>count(n , 0);
        mergesort(count , v , 0 , n - 1);
        return count;
    }
};