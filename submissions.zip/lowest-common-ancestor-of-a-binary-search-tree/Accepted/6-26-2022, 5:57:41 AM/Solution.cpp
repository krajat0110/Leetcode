// https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-search-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */

class Solution {
public:
    
bool find(TreeNode *node, int data){
    while(node != NULL){
    if(node -> val == data)
      return true;
    else if(node -> val > data){
      node = node -> left;
    }else
      node = node -> right;
   }
    return false;
}
    
   TreeNode *lowestCommonAncestor(TreeNode *root, TreeNode *p, TreeNode *q){
    TreeNode *LCA = NULL;
    while (root != NULL)
    {
        if (root->val < p->val && root->val < q->val)
        {
            root = root->right;
        }
        else if (root->val > p->val && root->val > q->val)
        {
            root = root->left;
        }
        else{
            LCA = root;
        break;
        }
    }
       return (LCA != NULL && find(LCA , p -> val) && find(LCA , q -> val))? LCA : NULL ;
   }  
};