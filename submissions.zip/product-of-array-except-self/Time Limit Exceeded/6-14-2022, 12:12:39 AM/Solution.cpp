// https://leetcode.com/problems/product-of-array-except-self

class Solution {
public:
    vector<int> productExceptSelf(vector<int>& nums) {
        vector<int>prod;
        int n = nums.size(); 
        for(int i = 0 ; i < n;i++){
            int sum = 1;
            for(int j = 0 ; j < n ; j++){
                if(j != i)
                sum = sum*nums[j];
            }
            prod.push_back(sum);
        }
        return prod;
    }
};