// https://leetcode.com/problems/maximum-points-you-can-obtain-from-cards

class Solution {
public:
    int maxScore(vector<int>& card, int k) {
        int n = card.size();
        int res = 0 , i = 0;
        while(k-->0){
            int n = card.size();
            if(card[i] > card[n-1]){
                res+= card[i];
                card[i] = -1;
            }else{
                res+= card[n-1];
                card.pop_back();
            }
        }
        
        return res;
    }
};