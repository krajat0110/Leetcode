// https://leetcode.com/problems/maximum-points-you-can-obtain-from-cards

class Solution {
public:
    int maxScore(vector<int>& card, int k) {
        int sum1 = 0 , n = card.size(),temp = 0;
        for(int i = n - k ; i < n ; i++) sum1 += card[i];
     //   cout<<sum1<<endl;
        for(int i = 0 ,temp = sum1; i < k ; i++){
            temp -= card[n-k+i];
            temp += card[i];
           // cout<<sum1<<" "<<temp<<" "<<res<<endl;
            sum1 = max(sum1 , temp);
        }
        return sum1;
    }
};