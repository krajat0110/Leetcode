// https://leetcode.com/problems/diameter-of-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    
    vector<int> diameterTree02(TreeNode *root){
    if (root == NULL)
        return {0,-1};

    vector<int> rd = diameterTree02(root->right);
    vector<int> ld = diameterTree02(root->left);

    // int rh = height(root->right);
    // int lh = height(root->left);

    vector<int>res(2); //{diameter , height};

    res[0] = max(max(ld[0] , rd[0]) , rd[1] + ld[1] + 2);
    res[1] = max(ld[1],rd[1]) + 1;

   return res;
}
    
    int diameterOfBinaryTree(TreeNode* root) {
        vector<int>ans = diameterTree02(root);
        return ans[0];
    }
};