// https://leetcode.com/problems/number-of-zero-filled-subarrays

class Solution {
public:
    long long zeroFilledSubarray(vector<int>& nums) {
        long long sum  =0 ,ans = 0;
        for(int i = 0 ; i < nums.size();i++){
            if(nums[i] == 0){
                sum  = sum + 1;
                ans += sum;
            }else{
                sum = 0;
            }
        }
        return ans;
    }
};