// https://leetcode.com/problems/wiggle-sort-ii

class Solution {
public:
    void wiggleSort(vector<int>& nums) {
         int n= nums.size();
        priority_queue<int> q(nums.begin(), nums.end()); //priority queue is in sorted order 
        for(int i=1; i<n; i += 2){ //we are putting large ele on odd places 
            nums[i] = q.top();
            q.pop();
        }
        for(int i=0; i<n; i += 2){ //smaller on even 
            nums[i] = q.top();
            q.pop();
        }
    }
};