// https://leetcode.com/problems/rabbits-in-forest

class Solution {
public:
    int numRabbits(vector<int>& answers) {
        vector<int>map(999 - 0 + 1 , 0);
        int ans = 0;
        for(auto ele : answers) {
            if(map[ele] == 0) ans += ele + 1;
            
            map[ele]++;
            
            if(map[ele] == ele + 1)
                map[ele] = 0;
        }
        return ans;
    }
};