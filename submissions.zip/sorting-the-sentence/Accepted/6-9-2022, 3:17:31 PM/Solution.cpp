// https://leetcode.com/problems/sorting-the-sentence

class Solution {
public:
    string sortSentence(string s) {
        string temp = "" , ans = "";
        vector<string>res(10);
        int n = s.size();
        for(int i = 0; i < n ; i++){
            if(s[i]>=48 && s[i]<=57){
                res[s[i] - 48] = temp + " ";
                temp = "";
                i++;
            }else{
                temp += s[i];
            }
        }
        
        for(auto ele : res){
            ans += ele;
        }
        ans.pop_back();
        return ans;
    }
};