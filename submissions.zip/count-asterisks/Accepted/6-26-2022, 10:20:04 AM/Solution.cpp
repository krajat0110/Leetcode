// https://leetcode.com/problems/count-asterisks

class Solution {
public:
    int countAsterisks(string s) {
        int n = s.size();
        int res = 0 , cnt = 0;
        for(int i = 0 ; i < n ; i++){
            if(s[i] == '|') cnt++;
            if(s[i] == '*' && cnt%2 == 0){
                res++;
            }
        }
        return res;
    }
};