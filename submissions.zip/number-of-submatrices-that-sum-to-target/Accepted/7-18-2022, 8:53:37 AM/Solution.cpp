// https://leetcode.com/problems/number-of-submatrices-that-sum-to-target

class Solution {
public:
    int countsubarray(vector<int> &colPrefixSum , int tar){
        unordered_map<int,int>map;
        map[0] = 1;
        int count = 0 , sum = 0;
        for(auto ele : colPrefixSum){
            sum += ele;
            count += map.find(sum - tar) != map.end() ? map[sum - tar] : 0;
            map[sum]++;   
        }
        return count;
    }
    
    
    int numSubmatrixSumTarget(vector<vector<int>>& mat, int tar) {
        int R = mat.size() , C = mat[0].size();
        int count = 0;
        for (int fixRow = 0; fixRow < R; fixRow++){
        vector<int> colPrefixSum(C, 0);
        for (int row = fixRow; row < R; row++){
            for (int col = 0; col < C; col++)
                colPrefixSum[col] += mat[row][col];
            count += countsubarray(colPrefixSum , tar);
          }
       }
        return count;
    }
};