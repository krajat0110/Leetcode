// https://leetcode.com/problems/rearrange-characters-to-make-target-string

class Solution {
public:
    int rearrangeCharacters(string s, string target) {
       int n1 = target.size(),n = s.size(),cnt = 0;
        if(n1 > n) return 0;
        vector<int>freq(128 , 0);
        int ei = 0;
       while(ei < n){
        freq[s[ei++]]++;
       }
        int si = 0;
        while(si < n1){
        //   cout<<target[si]<<" "<<freq[target[si]]<<" ----- ";
            if(freq[target[si]]-- == 0) return cnt;
        //    cout<<target[si]<<" "<<freq[target[si]]<<"  "<<si<<" "<<endl;

            if(si == n1-1){
               // cout<<target[si]<<endl;
                cnt++;
                si=0;
                continue;
            }
            si++;
        }
        return cnt;
    }
};