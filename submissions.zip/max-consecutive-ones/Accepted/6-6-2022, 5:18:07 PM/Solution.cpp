// https://leetcode.com/problems/max-consecutive-ones

class Solution {
public:
    int findMaxConsecutiveOnes(vector<int>& nums) {
        int cnt=0,prev = 0;
        for(auto ele : nums){
            if(ele == 1){
                cnt++;
            }else{
                if(prev < cnt)
                prev = cnt;
                cnt = 0;  
           }
       }
      return max(cnt,prev);  
    }
};