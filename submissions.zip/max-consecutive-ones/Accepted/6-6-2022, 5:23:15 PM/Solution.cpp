// https://leetcode.com/problems/max-consecutive-ones

class Solution {
public:
    int findMaxConsecutiveOnes(vector<int>& arr) {
        int n=arr.size(),ei=0,si=0,len=0;
        while(ei<n){
            if(arr[ei++] == 0){
                si=ei;
            }  
            
            len=max(len,ei-si);
        }
        return len;
    }
};