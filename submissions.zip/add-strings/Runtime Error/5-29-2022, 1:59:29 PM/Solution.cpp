// https://leetcode.com/problems/add-strings

class Solution {
public:
    string addStrings(string num1, string num2) {
        long long x = stol(num1);
        long long  y = stol(num2);
        
        string res = to_string(x+y);
        return res;
    }
};