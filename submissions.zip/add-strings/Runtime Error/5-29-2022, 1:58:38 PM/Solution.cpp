// https://leetcode.com/problems/add-strings

class Solution {
public:
    string addStrings(string num1, string num2) {
        int x = stoi(num1);
        int y = stoi(num2);
        
        string res = to_string(x+y);
        return res;
    }
};