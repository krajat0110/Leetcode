// https://leetcode.com/problems/count-number-of-nice-subarrays

class Solution {
public:
    
    int fxn(vector<int>& nums, int k){
        int si = 0 , ei = 0 , cnt = 0 , ans = 0;
        int n = nums.size();
        while(ei < n){
            
        if(nums[ei++] & 1 != 0)
            cnt++;
            
         while(cnt > k){   
         if(nums[si++] & 1 != 0)
            cnt--; 
          }
            ans += ei - si;
        }
        return ans;
    }
    
    int numberOfSubarrays(vector<int>& nums, int k) {
      return fxn(nums,k) - fxn(nums, k - 1);
    }
};