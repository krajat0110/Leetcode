// https://leetcode.com/problems/balance-a-binary-search-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) 
 * };
 */
class Solution {
public:
    vector<int> height;
    void updateHeight(TreeNode *root)
    {
        int lh = root->left != NULL ? height[root->left->val] : -1;
        int rh = root->right != NULL ? height[root->right->val] : -1;

        height[root->val] = max(lh, rh) + 1;
    }

    int getBal(TreeNode *root)
    {
        int lh = root->left != NULL ? height[root->left->val] : -1;
        int rh = root->right != NULL ? height[root->right->val] : -1;

        return lh - rh;
    }

    TreeNode *rightRotation(TreeNode *A)
    {
        TreeNode *B = A->left;
        TreeNode *BkaRight = B->right;

        B->right = A;
        A->left = BkaRight;

        B->right = getRotation(A);
        return getRotation(B);
    }

    //O(1)
    TreeNode *leftRotation(TreeNode *A)
    {
        TreeNode *B = A->right;
        TreeNode *BkaLeft = B->left;

        B->left = A;
        A->right = BkaLeft;

        B->left = getRotation(A);
        return getRotation(B);
    }

    TreeNode *getRotation(TreeNode *root)
    {

        updateHeight(root);
        if (getBal(root) >= 2) //ll,lr
        {
            if (getBal(root->left) >= 1) // ll
            {
                return rightRotation(root);
            }
            else // lr
            {
                root->left = leftRotation(root->left);
                return rightRotation(root);
            }
        }
        else if (getBal(root) <= -2) // rr,rl
        {

            if (getBal(root->right) <= -1) // rr
            {
                return leftRotation(root);
            }
            else // rl
            {
                root->right = rightRotation(root->right);
                return leftRotation(root);
            }
        }

        return root;
    }

    TreeNode *reconstructTree(TreeNode *root)
    {
        if (root == nullptr)
            return nullptr;

        root->left = reconstructTree(root->left);
        root->right = reconstructTree(root->right);

        return getRotation(root);
    }

    TreeNode *balanceBST(TreeNode *root)
    {
        height.resize((int)1e4 + 1, -1);
        return reconstructTree(root);
    }
};