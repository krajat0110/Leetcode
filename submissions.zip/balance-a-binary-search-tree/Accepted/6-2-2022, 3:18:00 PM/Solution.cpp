// https://leetcode.com/problems/balance-a-binary-search-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
       vector<int> height;

    void updateheight(TreeNode *root)
    {
        int lh = root->left != NULL ? height[root->left->val] : -1;
        int rh = root->right != NULL ? height[root->right->val] : -1;

        height[root->val] = max(lh, rh) + 1;
    }

    int getbal(TreeNode *root)
    {
        int lh = root->left != NULL ? height[root->left->val] : -1;
        int rh = root->right != NULL ? height[root->right->val] : -1;

        return lh - rh;
    }

    TreeNode *rightrotation(TreeNode *A)
    {
        TreeNode *B = A->left;
        TreeNode *Bkaright = B->right;

        B->right = A;
        A->left = Bkaright;

        B -> right = getrotation1(A);
        return getrotation1(B);
    }

    TreeNode *leftrotation(TreeNode *A)
    {

        TreeNode *B = A->right;
        TreeNode *Bkaleft = B->left;

        B->left = A;
        A->right = Bkaleft;

        B->left = getrotation1(A);
        return getrotation1(B);
    }
      TreeNode *getrotation1(TreeNode *root){
          
        updateheight(root);
        if(getbal(root) >= 2){
        if(getbal(root -> left) >= 1){ // ll
           return rightrotation(root);
        }else{ //lr
            root -> left = leftrotation(root -> left);
            return rightrotation(root);
        }
        }else if(getbal(root) <= -2){ 
            if (getbal(root->right) <= -1)
            { // rr
                return leftrotation(root);
            }
            else
            { // rl
                root->right = rightrotation(root->right);
                return leftrotation(root);
            }
        }
        return root;
    }

    TreeNode *reconstructTree(TreeNode *root)
    {
        if (root == NULL)
            return NULL;

        root->left = reconstructTree(root->left);
        root->right = reconstructTree(root->right);

        return getrotation1(root);
    }

    TreeNode *balanceBST(TreeNode *root)
    {
        height.resize((int)1e5 + 1, -1);
        return reconstructTree(root);
    }
};