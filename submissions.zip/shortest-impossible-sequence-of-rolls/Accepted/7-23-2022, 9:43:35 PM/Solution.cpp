// https://leetcode.com/problems/shortest-impossible-sequence-of-rolls

class Solution {
public:
    int shortestSequence(vector<int>& rolls, int k) {
        unordered_map<int, int> m;
        
        int ans = 1;
        for(int i = 0; i < rolls.size(); i++){
            m[rolls[i]]++;
            
            if(m.size() == k){
                m.clear();
                ans++;
            }
        }
        return ans;
    }
};