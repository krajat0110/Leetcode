// https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array

class Solution {
public:
    vector<int> searchRange(vector<int>& nums, int target) {
        int n = nums.size() , si = 0 , ei = n - 1;
        int temp = -1;
        bool flag = false;
        while(si < ei){
            int mid = (ei + si) / 2;
            if(nums[mid] > target)
                ei = mid;
            else 
                si = mid + 1; 
         if(nums[mid] == target){
             ei = mid;
             flag = true;
             break;
         }
        }
      if(flag == false) return {-1,-1};
        
        temp = ei;
        int i = temp , j = temp , ele = temp;
        
         while(i < n - 1 && nums[ele] == nums[i])
              i++;
        while(j > 0 && nums[ele] == nums[j])
            j--;
        
        return i == j ?  vector<int> {-1,-1} : vector<int> {j + 1 , i - 1};
    }
};