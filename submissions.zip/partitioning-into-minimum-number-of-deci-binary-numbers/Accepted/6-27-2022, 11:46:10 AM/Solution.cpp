// https://leetcode.com/problems/partitioning-into-minimum-number-of-deci-binary-numbers

class Solution {
public:
    int minPartitions(string n) {
        char res = '0';
        for(auto ele : n){
            if(ele > res)
                res = ele; 
              // cout<<res<<endl;
        }
        return res - '0';
    }
};