// https://leetcode.com/problems/two-sum

class Solution {
public:
    vector<int> twoSum(vector<int>& n, int target) {
        vector<int>V;
       for(int i=0;i<n.size();i++)
       {
        for(int j=i+1;j<n.size();j++)
       {
           if(n[j]==target-n[i]){
               V.push_back(i);
               V.push_back(j);
           }
        }
       }
        return V;
    }
};