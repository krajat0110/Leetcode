// https://leetcode.com/problems/backspace-string-compare

class Solution {
public:
    bool backspaceCompare(string s, string t) {
        vector<char> ele1 , ele2;
        
        for(char val : s){
            if(val == '#'){
                ele1.pop_back();
                continue;
            }
            ele1.push_back(val);
        }
        
           for(char val : t){
            if(val == '#'){
                ele2.pop_back();
                continue;
            }
            ele2.push_back(val);
        }
        return ele1 == ele2;
    }
};