// https://leetcode.com/problems/reverse-linked-list-ii

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public: 
    ListNode *th = NULL, *tt = NULL;
    void addfirstnode(ListNode *node){
    if (th == NULL)
        th = tt = node;
    else
    {
        node->next = th;
        th = node;
    }
}

//reverse in range
ListNode *reverseBetween(ListNode *head, int m, int n)
{
    if (head == NULL || head->next == NULL || m == n)
        return head;
    ListNode *curr = head;
    ListNode *small = NULL;
    int i = 1;
    while (curr != NULL)
    {
        while (i >= m && i <= n)
        {
            ListNode *greater = curr->next;
            curr->next = NULL;
            addfirstnode(curr);
            curr = greater;
            i++;
        }
        if (i > n)
        {
            if (small != NULL) 
            {
                small->next = th; //(m-1) jaha se reverse kari he uss se just ek peeche wali
                tt->next = curr;  // tt hamari reversed node ke end ko store kar rahi he
                return head;
            }
            else {  // first ele he range me he including head 
                tt->next = curr;
                return th;
            }
        }
        i++;
        small = curr;
        curr = curr->next;
    }
    return head;
}
};