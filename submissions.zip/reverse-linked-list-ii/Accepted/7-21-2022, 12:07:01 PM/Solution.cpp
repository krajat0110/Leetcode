// https://leetcode.com/problems/reverse-linked-list-ii

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public: 
    ListNode *th = NULL, *tt = NULL;
    void addfirstnode(ListNode *node){
    if (th == NULL)
        th = tt = node;
    else
    {
        node->next = th;
        th = node;
    }
}

ListNode *reverseBetween(ListNode *head, int m, int n)
{
    if(head == NULL || head -> next == NULL || m == n)
    return head;
    ListNode *curr = head;
    ListNode *prev = NULL;
    int i = 1;
    while(curr!=NULL){ 
    while(i>=m && i<=n){
      ListNode *fow = curr->next;
      curr -> next = NULL;
      addfirstnode(curr);
      curr = fow;
      i++;
      }
     if(i > n){
      if(prev !=NULL){
          prev -> next = th;
          tt -> next = curr;
          return head;
      }
      else{
          tt->next = curr;
          return th;
      }
     }
     i++;
     prev = curr;
     curr = curr -> next; 
    }
    return head;
    }
};