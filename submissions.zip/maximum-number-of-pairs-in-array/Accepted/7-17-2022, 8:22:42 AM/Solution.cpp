// https://leetcode.com/problems/maximum-number-of-pairs-in-array

class Solution {
public:
    vector<int> numberOfPairs(vector<int>& nums) {
        unordered_map<int,int>map;
        vector<int>ans;
        int ans1 = 0 , ans2 = 0;
        
        for(auto ele : nums) map[ele]++;
        
        for(auto ele : map){
            int value = ele.second;
            if(value % 2 == 0){
                int val = value / 2;
                ans1 += val;
              //  map[ele] = -1;
            }else if(value != -1 && value % 2 != 0){
                if(value == 1){
                    ans2 += 1;
                }else if(value > 2){
                    int pair = (value - 1) / 2;
                    ans1 += pair;
                    ans2++;
                }
            }
        }
        ans.push_back(ans1);
        ans.push_back(ans2);
        return ans;
    }
};