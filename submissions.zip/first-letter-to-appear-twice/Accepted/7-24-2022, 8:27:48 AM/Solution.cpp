// https://leetcode.com/problems/first-letter-to-appear-twice

class Solution {
public:
    char repeatedCharacter(string s) {
        unordered_map<char , int>map;
        
        for(char ele : s){
            map[ele]++;
             if(map[ele] == 2) return ele;
        }
        
        // for(auto ele : map){
        //     if(ele.second == 2) return ele.first;
        // }
        return -1;
    }
};