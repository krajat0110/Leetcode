// https://leetcode.com/problems/fibonacci-number

class Solution {
public:
    int fib(int n) {
        vector<int>dp(n+1);
        for(int i = 0 ; i <= n ; i++){
            if(i <= 1){
                dp[i] = i;
                continue;
            }
            
            int ans = fib(n-1) + fib(n-2);
            dp[i] = ans;
        }
        return dp[n];
    }
};