// https://leetcode.com/problems/fibonacci-number

class Solution {
public:
    int fib(int N) {
        vector<int>dp(N+1);
        for(int n = 0 ; n <= N ; n++){
            if(n<=1){
                dp[n] = n;
                continue;
            }
            int ans = dp[n-2] + dp[n-1];
            dp[n] = ans;
        }
        return dp[N];
    }
};