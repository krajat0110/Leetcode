// https://leetcode.com/problems/top-k-frequent-words

class Solution {
public:
    class cmp{
    public:
    bool operator()(pair<int,string> a, pair<int,string> b) const{
        if(a.first < b.first) return true;
        else if(a.first == b.first && a.second>b.second) return true;
        return false;
    }
};
    
       vector<string> topKFrequent(vector<string>& words, int k) {
       unordered_map<string,int> map;
       for(auto ele : words) map[ele]++;
       priority_queue<pair<int, string>, vector<pair<int, string>>,cmp> pq;
       for(auto &m : map){
         pq.push({m.second,m.first});
         //  pq.push({freq , val});
         //  if(pq.size() > k) pq.pop();
       }
        vector<string>res;
        while(k--){
            string temp = (pq.top().second);     
            res.push_back(temp);
            pq.pop();
        }
     return res;        
    }
};