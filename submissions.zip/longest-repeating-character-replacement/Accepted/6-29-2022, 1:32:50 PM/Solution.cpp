// https://leetcode.com/problems/longest-repeating-character-replacement

class Solution {
public:
    int characterReplacement(string s, int k) {
        int n = s.size() , ei = 0 , si = 0;
        unordered_map<char,int>map;
        
        int maxele = 0 , ans = 0;
        while(ei < n){
            map[s[ei]]++;
            
            maxele = max(maxele , map[s[ei]]);
             //When other characters become greater than k, we move window ahead.
            if(ei - si + 1 - maxele > k){
                map[s[si++]]--;
            }
            ans = max(ans , ei - si + 1);
            ei++;
        }
        return ans;
    }
};