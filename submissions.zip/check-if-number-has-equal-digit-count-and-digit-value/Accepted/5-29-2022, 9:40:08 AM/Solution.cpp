// https://leetcode.com/problems/check-if-number-has-equal-digit-count-and-digit-value

class Solution {
public:
    bool digitCount(string nums) {
        vector<int> count(10, 0);
        cout << count.size();
        for(int i = 0; i < nums.length(); i++){
            count[nums[i] - '0'] += 1;
        }
        
        for(int i = 0; i < nums.length(); i++){
            if(nums[i] - '0' != count[i]) return false;
        }
        
        return true;
    }
};