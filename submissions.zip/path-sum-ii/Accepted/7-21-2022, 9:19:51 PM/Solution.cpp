// https://leetcode.com/problems/path-sum-ii

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    
    void pathsum_(TreeNode *root , int targetSum , vector<int> &sans , vector<vector<int>> &ans){
        if(root == NULL ) return;
        if(root -> left == NULL && root -> right == NULL){
            if(root -> val - targetSum == 0){
                sans.push_back(root -> val);
                ans.push_back(sans);
                sans.pop_back();
            }
            return;
        }
                sans.push_back(root -> val);
                pathsum_(root -> left , targetSum - root -> val , sans , ans);
                pathsum_(root -> right , targetSum - root -> val , sans , ans);
                sans.pop_back();
    }
    
    vector<vector<int>> pathSum(TreeNode* root, int targetSum) {
        vector<int>sans;
        vector<vector<int>>ans;
        pathsum_(root , targetSum,sans , ans);
        return ans;
    }
};