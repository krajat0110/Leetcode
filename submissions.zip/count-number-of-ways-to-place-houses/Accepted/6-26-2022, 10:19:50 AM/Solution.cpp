// https://leetcode.com/problems/count-number-of-ways-to-place-houses

class Solution {
public:
    int countHousePlacements(int n) {
        long long int prev = 1;
    long long int curr = 2,temp;
    for(int i=2;i<=n;i++){
        temp = (prev % 1000000007 + curr % 1000000007) % 1000000007;
        prev = curr;
        curr = temp;
    }
    return (curr % 1000000007 * curr % 1000000007) % 1000000007;
    }
};