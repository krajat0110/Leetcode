// https://leetcode.com/problems/longest-substring-without-repeating-characters

class Solution {
public:
    int lengthOfLongestSubstring(string s){
      if(s.length() <= 1) return s.length();
        int n=s.length(),si=0,ei=0,len=0,count=0;
        vector<int> freq(128,0);
        
        while(ei<n){
            if(freq[s[ei++]]++ > 0){ //left left wala increment hoga then left wala 
                count++;
                //1. hgar condintion sahi hogi to cnt++ else not but these 2 will work fine then freq ++ then ei++
            }
            while(count>0)
                if(freq[s[si++]]-- > 1) count--;
            
            len=max(len,ei-si);
        }
        return len;
    }
};