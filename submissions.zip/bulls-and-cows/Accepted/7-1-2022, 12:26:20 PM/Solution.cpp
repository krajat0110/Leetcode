// https://leetcode.com/problems/bulls-and-cows

class Solution {
public:
    string getHint(string secret, string guess) {
        //count bulls first 
        int bulls = 0, cows = 0;
        vector<int> sMap(10, 0);
        vector<int> gMap(10, 0);
        
        for (int i = 0; i < guess.size(); i++) {
            if (secret[i] == guess[i]) {
                bulls++;  
            } else {
                sMap[secret[i] - '0']++;
                gMap[guess[i] - '0']++;
            } 
        }
        for (int i = 0; i < 10; i++) {
            cows += min(sMap[i], gMap[i]);
        }
        return to_string(bulls) + 'A' + to_string(cows) + 'B';
    }
};