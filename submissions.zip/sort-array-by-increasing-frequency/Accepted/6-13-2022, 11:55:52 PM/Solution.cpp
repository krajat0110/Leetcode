// https://leetcode.com/problems/sort-array-by-increasing-frequency

class Solution {
public:
    vector<int> frequencySort(vector<int>& nums) {
        unordered_map <int,int> mp;
        priority_queue <pair <int,int>> q;
        for(int i=0;i<nums.size();i++){
            mp[nums[i]]++;
        }
        for(auto &i:mp){
            q.push({-i.second,i.first});
           // cout<<q.top().first<<endl;
        }
        nums.clear();
        while(!q.empty()){
            
            for(int i=0;i<-(q.top().first);i++){
                nums.push_back(q.top().second);
            }
          //  cout<<q.top().first<<endl;
            q.pop();
           
        }
        return nums;
    }
};