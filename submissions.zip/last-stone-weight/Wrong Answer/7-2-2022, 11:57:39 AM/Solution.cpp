// https://leetcode.com/problems/last-stone-weight

class Solution {
public:
    int lastStoneWeight(vector<int>& stones) {
        priority_queue<int>pq;
        
        for(auto ele : stones){
            pq.push(ele);
        }
        while(pq.size() > 1){
           int ele1 = pq.top();
           pq.pop();
           int ele2 = pq.top();
           pq.pop();
            
           if(ele1 == ele2) continue;
            else {
                int diff = ele1 - ele2;
                pq.push(diff);
            }
        }
        return pq.top();
    }
};