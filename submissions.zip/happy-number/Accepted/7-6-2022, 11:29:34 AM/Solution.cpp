// https://leetcode.com/problems/happy-number

class Solution {
public:
    
    int digitSquareSum(int n) {
    int sum = 0, tmp;
    while (n) {
        tmp = n % 10;
        sum += tmp * tmp;
        n /= 10;
    }
    return sum;
}
    
    bool isHappy(int n) {
       int slow, fast;
    slow = fast = n;
    do {
        slow = digitSquareSum(slow);
        fast = digitSquareSum(digitSquareSum(fast));
      //  cout<<slow <<" "<<fast<<endl;
    } while(slow != fast);
     
        return fast == 1;
    }
};