// https://leetcode.com/problems/max-sum-of-a-pair-with-equal-sum-of-digits

class Solution {
public:
    
    int digitSum(int n)
    {
        int sum = 0;
        while (n != 0) {
            sum = sum + n % 10;
            n = n / 10;
        }
        return sum;
    }
    
    int maximumSum(vector<int>& arr) {
        int n = arr.size();

    unordered_map<int, int> mp;
    int ans = -1, pairi = 0, pairj = 0;
    for (int i = 0; i < n; i++) {

        int temp = digitSum(arr[i]);

        if (mp[temp] != 0) {
            if (arr[i] + mp[temp] > ans) {
                pairi = arr[i];
                pairj = mp[temp];
                ans = pairi + pairj;
            }
        }
        mp[temp] = max(arr[i], mp[temp]);
    }

        return ans;
    }
};