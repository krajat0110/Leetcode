// https://leetcode.com/problems/n-queens-ii

class Solution {
public:
    
vector<bool> row;
vector<bool> col;
vector<bool> diagonal;
vector<bool> antidiagonal;
    
    int nqueencombi_obtimize(int n, int r, string ans)
{
    if (r == n)
    {
        return 1;
    }

    int count = 0;
    for (int c = 0; c < n; c++)
    {
        if (!row[r] && !col[c] && !diagonal[r + c] && !antidiagonal[r - c + n - 1])
        {
            row[r] = col[c] = diagonal[r + c] = antidiagonal[r - c + n - 1] = true;
            count += nqueencombi_obtimize(n, r + 1, ans + "(" + to_string(r) + "," + to_string(c) + ")");
            row[r] = col[c] = diagonal[r + c] = antidiagonal[r - c + n - 1] = false;
        }
    }
    return count;
}
    
    
    int totalNQueens(int n) {
     row.resize(n, false);
    col.resize(n, false);
    diagonal.resize(2*n - 1, false);
    antidiagonal.resize(2* n - 1, false);
        
  return nqueencombi_obtimize(n, 0, "");
    }
};