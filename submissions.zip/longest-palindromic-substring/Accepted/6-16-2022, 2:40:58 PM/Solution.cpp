// https://leetcode.com/problems/longest-palindromic-substring

class Solution {
public:
    int calc(string s, int lt, int rt)
    {
        int l = lt, r = rt;
        while(l >= 0 && r < s.size() && s[l] == s[r])
        {
            l--;
            r++;
        }
        return r-l-1;
    }
    string longestPalindrome(string s) {
        int beg = 0, end = 0;
        for(int i = 0;i < s.size();i++)
        {
            int len1 = calc(s,i,i);
            int len2 = calc(s,i,i+1);
            int maxlen = max(len1,len2);
            if(maxlen > end-beg+1)
            {
                beg = i-(maxlen-1)/2;
                end = i+maxlen/2;
            }
        }
        return s.substr(beg,end-beg+1);
    }
};