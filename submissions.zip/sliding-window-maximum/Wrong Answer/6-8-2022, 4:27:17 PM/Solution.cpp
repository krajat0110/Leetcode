// https://leetcode.com/problems/sliding-window-maximum

class Solution {
public:
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        priority_queue<vector<int>>pq;
        vector<int>res;
        int n = nums.size();
          for(int i = 0 ; i < n ; i++){
              while(pq.size() != 0 && pq.top()[1] < i - k)
                  pq.pop();
              
              pq.push({nums[i] , i}); // pq index ke basis pe he
              
              if(i >= k - 1)
                  res.push_back(pq.top()[0]);
          }
        return res;
    }
};