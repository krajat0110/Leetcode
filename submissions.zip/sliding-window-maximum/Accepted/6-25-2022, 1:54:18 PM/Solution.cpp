// https://leetcode.com/problems/sliding-window-maximum

class Solution {
public:
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        list<int>dequeue;
        vector<int>res;
        int n = nums.size(), idx = 0;
          for(int i = 0 ; i < n ; i++){ 
              while(dequeue.size() != 0 && dequeue.front() <= i - k) //front ele exceed the window size
                  dequeue.pop_front();
              
              while(dequeue.size() != 0 && nums[dequeue.back()] <= nums[i]) //if last ele small or equal to next ele 
                  dequeue.pop_back();
              
              dequeue.push_back(i);
              
              if(i >= k - 1){
               //   cout<<i<<" "<<dequeue.front()<<" "<<dequeue.back()<<endl;
                res.push_back(nums[dequeue.front()]);  
              }
          } 
        return res;
    }
};