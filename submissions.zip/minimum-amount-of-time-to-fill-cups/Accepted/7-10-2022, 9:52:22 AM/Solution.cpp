// https://leetcode.com/problems/minimum-amount-of-time-to-fill-cups

class Solution {
public:
    int fillCups(vector<int>& amt) {
        priority_queue<int>pq;
        int cnt = 0;
        for(auto ele : amt) pq.push(ele);
        
        if(pq.top() == 0) return 0;
        
        while(pq.top() > 0){
            int ele1 = pq.top();
            pq.pop();
            int ele2 = pq.top();
            pq.pop();
            cnt++;
         //   cout<<ele1<<" "<<ele2<<endl;
            ele1--;
            ele2--;
            
         pq.push(ele1);
         pq.push(ele2);
        }
       // cout<<cnt<<" "<<pq.top()<<endl;
        return cnt;
    }
};