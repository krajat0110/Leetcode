// https://leetcode.com/problems/non-decreasing-array

class Solution {
public:
    bool checkPossibility(vector<int>& nums) {
        int cnt = 0 , n = nums.size();
        for(int i = 1; i < n;i++){
           if(nums[i] <= nums[i - 1]) cnt++;
           if(cnt > 1) return false;
        }
        return true;
    }
};