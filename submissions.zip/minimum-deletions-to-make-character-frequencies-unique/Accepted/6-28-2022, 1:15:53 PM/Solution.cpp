// https://leetcode.com/problems/minimum-deletions-to-make-character-frequencies-unique

class Solution {
public:
    int minDeletions(string s) {
        unordered_map<int,int>charcnt;
        unordered_map<int,int>uniquefreq;
        int count=0;
        
        for(int i=0;i<s.size();i++)
        {
         //   cout<<s[i]<<" "<<s[i] - 'a'<<endl;
            charcnt[s[i]]++;
            // 97 = a , 98 = b , 99 = c;
        }
        
        for(auto &it : charcnt)
        {
            int x= it.second;
        //    cout<<it.first<<" "<<it.second<<" "<<uniquefreq[x]<<endl;
            if(uniquefreq[x]!=0)
            {
                while(x>0 && uniquefreq[x]!=0)
                {
                    x--;
                    count++;
                }
            }
            if(x>0)
            {
                uniquefreq[x]++;
            }
        }
        return count;
    }
};