// https://leetcode.com/problems/smallest-number-in-infinite-set

class SmallestInfiniteSet {
public:
    priority_queue<int, vector<int>, greater<int>>pq;
    unordered_map<int , int>map;
    SmallestInfiniteSet(){
        int val = 1;
        while(val <= 1000){
        pq.push(val);
        map[val]++;
        val++;
        }
    }
    
    int popSmallest() {
      int ele = pq.top();
        pq.pop();
        map[ele]--;
        return ele;
    }
    
    void addBack(int num) {

       if(map[num] == 0){
           pq.push(num);
           map[num]++; 
           cout<<num<<"push"<<endl;
       }
    }
};

/**
 * Your SmallestInfiniteSet object will be instantiated and called as such:
 * SmallestInfiniteSet* obj = new SmallestInfiniteSet();
 * int param_1 = obj->popSmallest();
 * obj->addBack(num);
 */