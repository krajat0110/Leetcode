// https://leetcode.com/problems/two-sum-ii-input-array-is-sorted

class Solution {
public:
    vector<int> twoSum(vector<int>& arr, int target) {
        int si=0,n=arr.size(),ei=n-1;
        while(si<=ei){
            int mid = (si+ei)/2;
            if(arr[si]+arr[ei]<target){
                si++;
              }
            else if(arr[si]+arr[ei]>target){
                ei--;
            }
            else{
                return {si+1,ei+1};
            }
        }
        return {-1};
    }
};