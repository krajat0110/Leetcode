// https://leetcode.com/problems/min-cost-climbing-stairs

class Solution {
public:
    int minCostClimbingStairs(vector<int>& cost) {
        int n = cost.size();
        vector<int>dp(n);
        
        for(int i = 0 ; i < n ; i++){
            if(i <= 1){
                dp[i] = cost[i];
                continue;
            }
            int ans = min(dp[i-1],dp[i-2]) + cost[i];
            dp[i] = ans;
        }
        return min(dp[n-1],dp[n-2]);
    }
};